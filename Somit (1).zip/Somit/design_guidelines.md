# Somit! Design Guidelines

## Design Approach
**Reference-Based: Instagram + Minimalist Mobile Apps**
Drawing inspiration from Instagram's visual feed pattern combined with modern mobile-first rental platforms. The design prioritizes quick scanning, clear status indicators, and effortless interaction for high school students.

## Core Design Principles
1. **Mobile-First Containment**: Desktop views display a centered mobile container (max-width: 480px) with subtle shadow, simulating a phone interface
2. **Visual Scanning**: Instagram-style feed with prominent images enabling instant item recognition
3. **Trust & Clarity**: Blue accent colors and clean layouts reinforce reliability for school environment
4. **Immediate Feedback**: Clear status badges and alerts ensure students know rental availability at a glance

## Typography
- **Primary Font**: Inter or DM Sans (Google Fonts) - modern, highly legible
- **Hierarchy**:
  - App Title/Headers: 24-28px, semibold
  - Item Names: 18px, medium
  - Body/Details: 14-16px, regular
  - Status Badges/Labels: 12-14px, medium
  - Input Labels: 14px, medium

## Layout System
**Spacing Units**: Tailwind units of 2, 4, 6, and 8 (e.g., p-4, gap-6, mb-8)
- Card padding: p-4
- Section spacing: py-6 to py-8
- Icon-text gaps: gap-2
- Button padding: px-6 py-3

## Component Library

### A. Authentication Screen
- Centered card on clean background
- School logo/app name at top
- Two input fields (Student ID, Name) stacked vertically
- Primary blue button below inputs
- Minimal, trustworthy presentation

### B. Header (Fixed Top)
- **Search Bar**: Full-width with rounded corners (rounded-full), magnifying glass icon left, light gray background
- **Height**: 56-64px with safe padding
- **Layout**: Search takes 90% width, profile icon right
- Subtle bottom shadow for depth

### C. Item Feed Cards
- **Image**: Square ratio (1:1), fills card width, rounded-lg corners
- **Card Structure**: 
  - Item photo (top)
  - Item name (bold, 18px)
  - Category badge (small, rounded-full, gray background)
  - Status badge (Available: green, Rented: gray, Overdue: red)
  - Rent button (full-width, only enabled when Available)
- **Spacing**: Cards separated by 4-6 units vertical gap
- **Shadow**: Soft shadow (shadow-md) for each card

### D. Status Badges
- **Pill-shaped** (rounded-full) with colored backgrounds:
  - Available: Light green background, dark green text
  - Rented: Light gray background, dark gray text  
  - Overdue: Light red background, dark red text
- Small padding (px-3 py-1), 12-14px font

### E. Rental Modal/Sheet
- Slides up from bottom on mobile
- **Content**:
  - Item photo thumbnail (top)
  - "Reason for Rental" textarea (3-4 rows)
  - Due date picker (calendar icon)
  - Confirm button (primary blue, full-width)
  - Cancel button (ghost style, full-width)
- Padding: p-6, rounded-t-2xl

### F. My Page
- **Alert Banner** (if overdue items exist):
  - Red/orange background strip at top
  - Warning icon + "You have overdue items" text
  - Attention-grabbing but not aggressive
- **Rented Items List**:
  - Similar to feed cards but compact
  - Includes "Return" button (green)
  - Shows due date prominently
  - Days remaining counter

### G. Buttons
- **Primary (Rent/Confirm)**: Blue background, white text, rounded-lg, shadow-sm
- **Secondary (Return)**: Green background, white text
- **Ghost (Cancel)**: Transparent background, blue text, border
- **Disabled State**: Gray background, reduced opacity
- All buttons: px-6 py-3, medium font weight

### H. Navigation
- **Bottom Nav Bar** (fixed):
  - 3 items: Feed (Home), My Page, Profile
  - Icons with labels below
  - Active state: Blue color
  - Height: 64px

## Images
**Required Images**:
1. **Item Photos**: Square (400x400px minimum), clear product shots on white/neutral background
2. **Empty State**: Illustration when no items available or rented
3. **App Logo**: Simple icon for login screen (80x80px)

**Placement**:
- Item cards: Feature image at top of each card
- My Page: Thumbnail version (60x60px) left of item details
- No large hero images - focus is on item catalog

## Accessibility
- Minimum touch target: 44x44px for all interactive elements
- High contrast for status badges (WCAG AA compliance)
- Clear focus states with blue outline
- Descriptive alt text for all item images

## Animations
**Minimal & Purposeful**:
- Card tap: Subtle scale (0.98) on press
- Modal entry: Slide up with ease-out (200ms)
- Status change: Gentle fade transition (150ms)
- No decorative animations

## Desktop Adaptation
- Center container (max-w-md) with light gray background around it
- Subtle box shadow on container (shadow-xl)
- Maintain mobile proportions - do NOT expand to full desktop width
- Same interactions and components, just centered presentation