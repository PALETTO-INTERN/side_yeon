import type { User, InsertUser, Item, InsertItem, Rental, InsertRental, RentalWithItem } from "@shared/schema";
import { randomUUID } from "crypto";
import { isPast } from "date-fns";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByStudentId(studentId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Items
  getItems(): Promise<Item[]>;
  getItem(id: string): Promise<Item | undefined>;
  createItem(item: InsertItem): Promise<Item>;
  updateItemStatus(id: string, status: "AVAILABLE" | "RENTED"): Promise<Item | undefined>;
  
  // Rentals
  getRentals(): Promise<Rental[]>;
  getRentalsByUserId(userId: string): Promise<RentalWithItem[]>;
  getRental(id: string): Promise<Rental | undefined>;
  createRental(rental: InsertRental): Promise<Rental>;
  returnRental(id: string): Promise<Rental | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private items: Map<string, Item>;
  private rentals: Map<string, Rental>;

  constructor() {
    this.users = new Map();
    this.items = new Map();
    this.rentals = new Map();
    
    // Initialize with sample items
    this.initializeSampleItems();
  }

  private initializeSampleItems() {
    const sampleItems: Omit<Item, "id">[] = [
      {
        name: "Umbrella",
        description: "Compact folding umbrella for rainy days",
        imageUrl: "https://images.unsplash.com/photo-1534309466160-70b22cc6252c?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Daily",
      },
      {
        name: "Laptop (MacBook Air)",
        description: "M1 MacBook Air for study and projects",
        imageUrl: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Electronics",
      },
      {
        name: "Basketball",
        description: "Official size basketball for games",
        imageUrl: "https://images.unsplash.com/photo-1519861531473-9200262188bf?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Sports",
      },
      {
        name: "Gym Clothes Set",
        description: "Complete gym outfit with shorts and t-shirt",
        imageUrl: "https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Sports",
      },
      {
        name: "Scientific Calculator",
        description: "TI-84 Plus for math and science classes",
        imageUrl: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Study",
      },
      {
        name: "Phone Charger",
        description: "Fast charging USB-C charger with cable",
        imageUrl: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Electronics",
      },
      {
        name: "Yoga Mat",
        description: "Non-slip yoga mat for exercise",
        imageUrl: "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Sports",
      },
      {
        name: "Study Lamp",
        description: "LED desk lamp with adjustable brightness",
        imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop",
        status: "AVAILABLE",
        category: "Study",
      },
    ];

    sampleItems.forEach((item) => {
      const id = randomUUID();
      this.items.set(id, { ...item, id });
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByStudentId(studentId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.studentId === studentId
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Items
  async getItems(): Promise<Item[]> {
    return Array.from(this.items.values());
  }

  async getItem(id: string): Promise<Item | undefined> {
    return this.items.get(id);
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    const id = randomUUID();
    const item: Item = { 
      ...insertItem, 
      id, 
      status: "AVAILABLE",
      description: insertItem.description || "",
    };
    this.items.set(id, item);
    return item;
  }

  async updateItemStatus(id: string, status: "AVAILABLE" | "RENTED"): Promise<Item | undefined> {
    const item = this.items.get(id);
    if (item) {
      item.status = status;
      this.items.set(id, item);
      return item;
    }
    return undefined;
  }

  // Rentals
  async getRentals(): Promise<Rental[]> {
    const rentals = Array.from(this.rentals.values());
    // Update overdue status
    return rentals.map((rental) => {
      if (rental.status === "ACTIVE" && isPast(new Date(rental.dueAt))) {
        rental.status = "OVERDUE";
        this.rentals.set(rental.id, rental);
      }
      return rental;
    });
  }

  async getRentalsByUserId(userId: string): Promise<RentalWithItem[]> {
    const rentals = await this.getRentals();
    const userRentals = rentals.filter((rental) => rental.userId === userId);
    
    return userRentals.map((rental) => {
      const item = this.items.get(rental.itemId);
      return {
        ...rental,
        item: item!,
      };
    }).filter((rental) => rental.item);
  }

  async getRental(id: string): Promise<Rental | undefined> {
    const rental = this.rentals.get(id);
    if (rental && rental.status === "ACTIVE" && isPast(new Date(rental.dueAt))) {
      rental.status = "OVERDUE";
      this.rentals.set(id, rental);
    }
    return rental;
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    const id = randomUUID();
    const rental: Rental = {
      id,
      userId: insertRental.userId,
      itemId: insertRental.itemId,
      reason: insertRental.reason,
      rentedAt: new Date().toISOString(),
      dueAt: insertRental.dueAt,
      returnedAt: null,
      status: "ACTIVE",
    };
    this.rentals.set(id, rental);
    
    // Update item status to RENTED
    await this.updateItemStatus(insertRental.itemId, "RENTED");
    
    return rental;
  }

  async returnRental(id: string): Promise<Rental | undefined> {
    const rental = this.rentals.get(id);
    if (rental) {
      rental.status = "RETURNED";
      rental.returnedAt = new Date().toISOString();
      this.rentals.set(id, rental);
      
      // Update item status back to AVAILABLE
      await this.updateItemStatus(rental.itemId, "AVAILABLE");
      
      return rental;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
