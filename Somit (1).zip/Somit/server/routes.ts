import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertRentalSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = insertUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid input", details: result.error.errors });
      }
      
      const { studentId, name } = result.data;
      
      // Check if user exists
      let user = await storage.getUserByStudentId(studentId);
      
      if (!user) {
        // Create new user
        user = await storage.createUser({ studentId, name });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Failed to login" });
    }
  });

  // Items routes
  app.get("/api/items", async (_req, res) => {
    try {
      const items = await storage.getItems();
      res.json(items);
    } catch (error) {
      console.error("Get items error:", error);
      res.status(500).json({ error: "Failed to get items" });
    }
  });

  app.get("/api/items/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Get item error:", error);
      res.status(500).json({ error: "Failed to get item" });
    }
  });

  // Rentals routes
  app.get("/api/rentals", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (userId) {
        const rentals = await storage.getRentalsByUserId(userId);
        return res.json(rentals);
      }
      const rentals = await storage.getRentals();
      res.json(rentals);
    } catch (error) {
      console.error("Get rentals error:", error);
      res.status(500).json({ error: "Failed to get rentals" });
    }
  });

  app.post("/api/rentals", async (req, res) => {
    try {
      const result = insertRentalSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid input", details: result.error.errors });
      }
      
      // Check if item is available
      const item = await storage.getItem(result.data.itemId);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      if (item.status !== "AVAILABLE") {
        return res.status(400).json({ error: "Item is not available for rent" });
      }
      
      const rental = await storage.createRental(result.data);
      res.status(201).json(rental);
    } catch (error) {
      console.error("Create rental error:", error);
      res.status(500).json({ error: "Failed to create rental" });
    }
  });

  app.patch("/api/rentals/:id/return", async (req, res) => {
    try {
      const rental = await storage.returnRental(req.params.id);
      if (!rental) {
        return res.status(404).json({ error: "Rental not found" });
      }
      res.json(rental);
    } catch (error) {
      console.error("Return rental error:", error);
      res.status(500).json({ error: "Failed to return rental" });
    }
  });

  return httpServer;
}
