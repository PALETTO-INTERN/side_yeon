import { z } from "zod";

// User schema for student login
export const users = {
  id: "",
  studentId: "",
  name: "",
};

export const insertUserSchema = z.object({
  studentId: z.string().min(1, "Student ID is required"),
  name: z.string().min(1, "Name is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = {
  id: string;
  studentId: string;
  name: string;
};

// Item status enum
export const ItemStatus = {
  AVAILABLE: "AVAILABLE",
  RENTED: "RENTED",
} as const;

export type ItemStatusType = (typeof ItemStatus)[keyof typeof ItemStatus];

// Item category enum
export const ItemCategory = {
  ELECTRONICS: "Electronics",
  SPORTS: "Sports",
  STUDY: "Study",
  DAILY: "Daily",
  OTHER: "Other",
} as const;

export type ItemCategoryType = (typeof ItemCategory)[keyof typeof ItemCategory];

// Item schema
export const insertItemSchema = z.object({
  name: z.string().min(1, "Item name is required"),
  description: z.string().optional(),
  imageUrl: z.string().url("Must be a valid URL"),
  category: z.string(),
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  status: ItemStatusType;
  category: string;
};

// Rental status enum
export const RentalStatus = {
  ACTIVE: "ACTIVE",
  RETURNED: "RETURNED",
  OVERDUE: "OVERDUE",
} as const;

export type RentalStatusType = (typeof RentalStatus)[keyof typeof RentalStatus];

// Rental schema
export const insertRentalSchema = z.object({
  userId: z.string(),
  itemId: z.string(),
  reason: z.string().min(1, "Please provide a reason for rental"),
  dueAt: z.string(),
});

export type InsertRental = z.infer<typeof insertRentalSchema>;
export type Rental = {
  id: string;
  userId: string;
  itemId: string;
  reason: string;
  rentedAt: string;
  dueAt: string;
  returnedAt: string | null;
  status: RentalStatusType;
};

// Extended rental type with item details for My Page
export type RentalWithItem = Rental & {
  item: Item;
};
