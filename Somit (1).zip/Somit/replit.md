# Somit! - Dormitory Rental Service

## Overview

Somit! is a web-based rental management application designed for dormitory high school students at Busoma. The application enables students to easily rent and return items like umbrellas, laptops, and gym equipment through an Instagram-inspired mobile-first interface. The system features simple student ID authentication, real-time item availability tracking, and automated overdue status management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- Mobile-first responsive design with centered desktop container (max-width: 480px)

**UI Component Strategy**
- Shadcn/ui component library with Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- DM Sans / Inter typography from Google Fonts
- Instagram-inspired card-based feed layout with square aspect ratio images

**State Management**
- TanStack Query (React Query) for server state management
- Local storage for client-side authentication persistence
- React Context for auth state sharing across components

**Design System**
- Blue accent colors for trust and school environment compatibility
- Consistent spacing using Tailwind's 2/4/6/8 unit system
- Fixed header with search and bottom navigation bar
- Status-driven UI with color-coded badges (green/gray/red)

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for API endpoints
- HTTP server with JSON request/response handling
- RESTful API design pattern

**API Structure**
- `/api/auth/login` - Simple student ID + name authentication
- `/api/items` - Item listing and details
- `/api/rentals` - Rental creation, listing, and return operations
- No session management - stateless authentication with client-side storage

**Data Layer**
- In-memory storage implementation (MemStorage class)
- Interface-based storage abstraction (IStorage) for future database migration
- Drizzle ORM configuration prepared for PostgreSQL migration
- Schema definitions using Zod for validation

**Data Model**
- Users: Student ID, name (simple authentication)
- Items: Name, description, image URL, status (AVAILABLE/RENTED), category
- Rentals: User reference, item reference, reason, due date, status (ACTIVE/RETURNED/OVERDUE)
- Calculated overdue status based on due date comparison

### Key Architectural Decisions

**Simple Authentication**
- *Problem*: Students need quick access without complex authentication
- *Solution*: Student ID + name login that creates/retrieves user on first login
- *Rationale*: Minimizes friction for school environment where student IDs are already managed
- *Trade-off*: Less secure but appropriate for low-risk rental tracking within a trusted school environment

**Mobile-First Container Design**
- *Problem*: Need consistent experience across devices
- *Solution*: Desktop displays centered mobile container with shadow
- *Rationale*: Simulates phone interface, maintains design consistency
- *Trade-off*: Desktop space underutilized but provides familiar UX

**In-Memory Storage with Database Preparation**
- *Problem*: Need rapid development with future scalability
- *Solution*: Interface-based storage with in-memory implementation and Drizzle ORM config
- *Rationale*: Enables immediate development while preparing for PostgreSQL migration
- *Trade-off*: Data lost on restart but acceptable for development phase

**Instagram-Style Feed Pattern**
- *Problem*: Students need to quickly scan available items
- *Solution*: Vertical scrolling feed with large square images and minimal text
- *Rationale*: Familiar pattern that prioritizes visual recognition over text
- *Trade-off*: More scrolling required but faster visual scanning

**Client-Side Overdue Calculation**
- *Problem*: Items need automatic overdue status without background jobs
- *Solution*: Calculate overdue status on-demand using date-fns
- *Rationale*: Simplifies backend, no scheduled tasks needed
- *Trade-off*: Status only updates when data is fetched

## External Dependencies

### UI Component Libraries
- **Radix UI**: Headless UI primitives for accessible components (dialogs, sheets, popovers, etc.)
- **Shadcn/ui**: Pre-built component system built on Radix UI
- **Lucide React**: Icon library for consistent iconography

### State & Data Management
- **TanStack Query**: Server state synchronization and caching
- **React Hook Form**: Form state management with validation
- **Zod**: Schema validation for forms and API data
- **date-fns**: Date manipulation and formatting

### Styling
- **Tailwind CSS**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx / tailwind-merge**: Conditional class name composition

### Database (Configured but Not Active)
- **Drizzle ORM**: Prepared for PostgreSQL integration
- **pg**: PostgreSQL client library included
- **connect-pg-simple**: Session store for future session management

### Build Tools
- **Vite**: Fast development server and build tool
- **esbuild**: Fast JavaScript bundler for production builds
- **TypeScript**: Type safety across frontend and backend

### Fonts
- **Google Fonts**: DM Sans and Inter for modern, legible typography