import { differenceInDays, format, isPast } from "date-fns";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package, Clock, AlertTriangle } from "lucide-react";
import type { RentalWithItem } from "@shared/schema";

interface RentalCardProps {
  rental: RentalWithItem;
  onReturn: (rental: RentalWithItem) => void;
  isPending?: boolean;
}

export function RentalCard({ rental, onReturn, isPending }: RentalCardProps) {
  const dueDate = new Date(rental.dueAt);
  const today = new Date();
  const daysRemaining = differenceInDays(dueDate, today);
  const isOverdue = isPast(dueDate) && rental.status === "ACTIVE";
  const isActive = rental.status === "ACTIVE";

  const getStatusBadge = () => {
    if (isOverdue || rental.status === "OVERDUE") {
      return (
        <Badge 
          variant="destructive" 
          className="rounded-full text-xs"
          data-testid={`badge-rental-status-${rental.id}`}
        >
          <AlertTriangle className="w-3 h-3 mr-1" />
          Overdue
        </Badge>
      );
    }
    if (rental.status === "RETURNED") {
      return (
        <Badge 
          variant="secondary" 
          className="rounded-full text-xs"
          data-testid={`badge-rental-status-${rental.id}`}
        >
          Returned
        </Badge>
      );
    }
    return (
      <Badge 
        variant="secondary" 
        className="rounded-full text-xs bg-primary/10 text-primary"
        data-testid={`badge-rental-status-${rental.id}`}
      >
        Active
      </Badge>
    );
  };

  const getDaysRemainingText = () => {
    if (!isActive) return null;
    if (isOverdue) {
      const overdueDays = Math.abs(daysRemaining);
      return (
        <span className="text-destructive font-medium">
          {overdueDays} {overdueDays === 1 ? "day" : "days"} overdue
        </span>
      );
    }
    if (daysRemaining === 0) {
      return <span className="text-amber-600 dark:text-amber-500 font-medium">Due today</span>;
    }
    if (daysRemaining === 1) {
      return <span className="text-amber-600 dark:text-amber-500 font-medium">Due tomorrow</span>;
    }
    return (
      <span className="text-muted-foreground">
        {daysRemaining} days remaining
      </span>
    );
  };

  return (
    <Card 
      className="overflow-hidden"
      data-testid={`card-rental-${rental.id}`}
    >
      <div className="flex gap-4 p-4">
        <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden flex-shrink-0">
          {rental.item.imageUrl ? (
            <img
              src={rental.item.imageUrl}
              alt={rental.item.name}
              className="w-full h-full object-cover"
              data-testid={`img-rental-item-${rental.id}`}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Package className="w-8 h-8 text-muted-foreground/30" />
            </div>
          )}
        </div>
        
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 
              className="font-semibold truncate"
              data-testid={`text-rental-item-name-${rental.id}`}
            >
              {rental.item.name}
            </h3>
            {getStatusBadge()}
          </div>
          
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            <span>Due: {format(dueDate, "MMM d, yyyy")}</span>
          </div>
          
          <div className="text-sm">
            {getDaysRemainingText()}
          </div>

          {rental.reason && (
            <p className="text-sm text-muted-foreground line-clamp-1">
              Reason: {rental.reason}
            </p>
          )}
        </div>
      </div>
      
      {isActive && (
        <div className="px-4 pb-4">
          <Button
            onClick={() => onReturn(rental)}
            disabled={isPending}
            variant="secondary"
            className="w-full bg-green-600 hover:bg-green-700 text-white"
            data-testid={`button-return-${rental.id}`}
          >
            {isPending ? "Returning..." : "Return Item"}
          </Button>
        </div>
      )}
    </Card>
  );
}
