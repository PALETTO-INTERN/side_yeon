import { Package, Search, Inbox } from "lucide-react";

type EmptyStateType = "no-items" | "no-results" | "no-rentals";

interface EmptyStateProps {
  type: EmptyStateType;
  searchQuery?: string;
}

const emptyStates = {
  "no-items": {
    icon: Package,
    title: "No items available",
    description: "Check back later for new items to rent.",
  },
  "no-results": {
    icon: Search,
    title: "No results found",
    description: "Try adjusting your search to find what you're looking for.",
  },
  "no-rentals": {
    icon: Inbox,
    title: "No rentals yet",
    description: "Items you rent will appear here.",
  },
};

export function EmptyState({ type, searchQuery }: EmptyStateProps) {
  const state = emptyStates[type];
  const Icon = state.icon;

  return (
    <div 
      className="flex flex-col items-center justify-center py-16 px-4 text-center"
      data-testid={`empty-state-${type}`}
    >
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="font-semibold text-lg mb-1">{state.title}</h3>
      <p className="text-muted-foreground text-sm max-w-xs">
        {type === "no-results" && searchQuery
          ? `No items match "${searchQuery}"`
          : state.description}
      </p>
    </div>
  );
}
