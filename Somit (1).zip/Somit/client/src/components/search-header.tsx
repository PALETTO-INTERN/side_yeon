import { Search, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";

interface SearchHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function SearchHeader({ searchQuery, onSearchChange }: SearchHeaderProps) {
  const { user } = useAuth();

  return (
    <header 
      className="fixed top-0 left-0 right-0 h-14 bg-background/95 backdrop-blur-sm border-b border-border z-50"
      data-testid="header-search"
    >
      <div className="max-w-md mx-auto h-full flex items-center gap-3 px-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search items..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-9 pr-4 h-9 rounded-full bg-muted/50 border-0 focus-visible:ring-1 focus-visible:ring-primary"
            data-testid="input-search"
          />
        </div>
        <Avatar className="w-8 h-8">
          <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
            {user?.name?.charAt(0).toUpperCase() || <User className="w-4 h-4" />}
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
