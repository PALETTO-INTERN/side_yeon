import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package } from "lucide-react";
import type { Item } from "@shared/schema";

interface ItemCardProps {
  item: Item;
  onRent: (item: Item) => void;
}

export function ItemCard({ item, onRent }: ItemCardProps) {
  const isAvailable = item.status === "AVAILABLE";

  return (
    <Card 
      className="overflow-hidden"
      data-testid={`card-item-${item.id}`}
    >
      <div className="aspect-square relative bg-muted overflow-hidden">
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.name}
            className="w-full h-full object-cover"
            data-testid={`img-item-${item.id}`}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Package className="w-16 h-16 text-muted-foreground/30" />
          </div>
        )}
      </div>
      
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 
              className="font-semibold text-lg truncate"
              data-testid={`text-item-name-${item.id}`}
            >
              {item.name}
            </h3>
            {item.description && (
              <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                {item.description}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2 flex-wrap">
          <Badge 
            variant="secondary" 
            className="rounded-full text-xs"
            data-testid={`badge-category-${item.id}`}
          >
            {item.category}
          </Badge>
          <Badge
            variant={isAvailable ? "default" : "secondary"}
            className={`rounded-full text-xs ${
              isAvailable 
                ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" 
                : "bg-muted text-muted-foreground"
            }`}
            data-testid={`badge-status-${item.id}`}
          >
            {isAvailable ? "Available" : "Rented"}
          </Badge>
        </div>
        
        <Button
          onClick={() => onRent(item)}
          disabled={!isAvailable}
          className="w-full"
          data-testid={`button-rent-${item.id}`}
        >
          {isAvailable ? "Rent" : "Unavailable"}
        </Button>
      </div>
    </Card>
  );
}
