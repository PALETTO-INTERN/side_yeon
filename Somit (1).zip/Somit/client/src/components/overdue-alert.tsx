import { AlertTriangle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface OverdueAlertProps {
  count: number;
}

export function OverdueAlert({ count }: OverdueAlertProps) {
  if (count === 0) return null;

  return (
    <Alert 
      variant="destructive" 
      className="border-0 rounded-none bg-destructive/10"
      data-testid="alert-overdue"
    >
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription className="font-medium">
        You have {count} overdue {count === 1 ? "item" : "items"}. Please return {count === 1 ? "it" : "them"} as soon as possible.
      </AlertDescription>
    </Alert>
  );
}
