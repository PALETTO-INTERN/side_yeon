import { useState } from "react";
import { format, addDays } from "date-fns";
import { CalendarIcon, Package } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import type { Item } from "@shared/schema";

interface RentalSheetProps {
  item: Item | null;
  open: boolean;
  onClose: () => void;
  onConfirm: (reason: string, dueDate: Date) => void;
  isPending?: boolean;
}

export function RentalSheet({ item, open, onClose, onConfirm, isPending }: RentalSheetProps) {
  const [reason, setReason] = useState("");
  const [dueDate, setDueDate] = useState<Date>(addDays(new Date(), 3));
  const [calendarOpen, setCalendarOpen] = useState(false);

  const handleConfirm = () => {
    if (reason.trim() && dueDate) {
      onConfirm(reason.trim(), dueDate);
      setReason("");
      setDueDate(addDays(new Date(), 3));
    }
  };

  const handleClose = () => {
    setReason("");
    setDueDate(addDays(new Date(), 3));
    onClose();
  };

  if (!item) return null;

  return (
    <Sheet open={open} onOpenChange={handleClose}>
      <SheetContent side="bottom" className="rounded-t-2xl max-w-md mx-auto">
        <SheetHeader className="text-left pb-4">
          <SheetTitle>Rent Item</SheetTitle>
          <SheetDescription>
            Fill in the details to rent this item
          </SheetDescription>
        </SheetHeader>
        
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden flex-shrink-0">
              {item.imageUrl ? (
                <img
                  src={item.imageUrl}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="w-8 h-8 text-muted-foreground/30" />
                </div>
              )}
            </div>
            <div>
              <h3 
                className="font-semibold"
                data-testid="text-rental-item-name"
              >
                {item.name}
              </h3>
              <p className="text-sm text-muted-foreground">{item.category}</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Rental</Label>
            <Textarea
              id="reason"
              placeholder="e.g., Need for PE class tomorrow..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              className="resize-none"
              data-testid="input-rental-reason"
            />
          </div>

          <div className="space-y-2">
            <Label>Due Date</Label>
            <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                  data-testid="button-select-date"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(dueDate, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={(date) => {
                    if (date) {
                      setDueDate(date);
                      setCalendarOpen(false);
                    }
                  }}
                  disabled={(date) => date < new Date()}
                  initialFocus
                  data-testid="calendar-due-date"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <Button
              onClick={handleConfirm}
              disabled={!reason.trim() || isPending}
              className="w-full"
              data-testid="button-confirm-rental"
            >
              {isPending ? "Processing..." : "Confirm Rental"}
            </Button>
            <Button
              variant="ghost"
              onClick={handleClose}
              className="w-full"
              data-testid="button-cancel-rental"
            >
              Cancel
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
