import { useLocation } from "wouter";
import { BottomNav } from "@/components/bottom-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { LogOut, User, IdCard, Package } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { RentalWithItem } from "@shared/schema";

export default function Profile() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: rentals = [] } = useQuery<RentalWithItem[]>({
    queryKey: ["/api/rentals", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/rentals?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch rentals");
      return res.json();
    },
    enabled: !!user?.id,
  });

  const activeCount = rentals.filter((r) => r.status === "ACTIVE" || r.status === "OVERDUE").length;
  const totalRentals = rentals.length;

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    });
    setLocation("/login");
  };

  return (
    <div className="min-h-screen bg-background">
      <header 
        className="fixed top-0 left-0 right-0 h-14 bg-background/95 backdrop-blur-sm border-b border-border z-50"
        data-testid="header-profile"
      >
        <div className="max-w-md mx-auto h-full flex items-center px-4">
          <h1 className="text-xl font-semibold">Profile</h1>
        </div>
      </header>
      
      <main className="pt-14 pb-20 max-w-md mx-auto">
        <div className="p-4 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="w-20 h-20 mb-4">
                  <AvatarFallback className="bg-primary/10 text-primary text-2xl font-semibold">
                    {user?.name?.charAt(0).toUpperCase() || <User className="w-8 h-8" />}
                  </AvatarFallback>
                </Avatar>
                <h2 
                  className="text-xl font-semibold"
                  data-testid="text-user-name"
                >
                  {user?.name || "Student"}
                </h2>
                <p 
                  className="text-muted-foreground"
                  data-testid="text-student-id"
                >
                  ID: {user?.studentId || "Unknown"}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Rental Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Package className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Active Rentals</p>
                    <p className="text-sm text-muted-foreground">Currently borrowed</p>
                  </div>
                </div>
                <span 
                  className="text-2xl font-bold text-primary"
                  data-testid="text-active-count"
                >
                  {activeCount}
                </span>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <IdCard className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Total Rentals</p>
                    <p className="text-sm text-muted-foreground">All time</p>
                  </div>
                </div>
                <span 
                  className="text-2xl font-bold"
                  data-testid="text-total-count"
                >
                  {totalRentals}
                </span>
              </div>
            </CardContent>
          </Card>

          <Button
            variant="outline"
            className="w-full"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}
