import { useQuery, useMutation } from "@tanstack/react-query";
import { BottomNav } from "@/components/bottom-nav";
import { RentalCard } from "@/components/rental-card";
import { OverdueAlert } from "@/components/overdue-alert";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isPast } from "date-fns";
import type { RentalWithItem } from "@shared/schema";

function RentalCardSkeleton() {
  return (
    <div className="bg-card rounded-lg border border-card-border p-4">
      <div className="flex gap-4">
        <Skeleton className="w-16 h-16 rounded-lg" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-4 w-1/3" />
        </div>
      </div>
      <Skeleton className="h-9 w-full mt-4" />
    </div>
  );
}

export default function MyRentals() {
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: rentals = [], isLoading } = useQuery<RentalWithItem[]>({
    queryKey: ["/api/rentals", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/rentals?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch rentals");
      return res.json();
    },
    enabled: !!user?.id,
  });

  const returnMutation = useMutation({
    mutationFn: async (rentalId: string) => {
      return apiRequest("PATCH", `/api/rentals/${rentalId}/return`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      toast({
        title: "Item Returned",
        description: "Thank you for returning the item on time!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to return item. Please try again.",
        variant: "destructive",
      });
    },
  });

  const activeRentals = rentals.filter((r) => r.status === "ACTIVE" || r.status === "OVERDUE");
  const returnedRentals = rentals.filter((r) => r.status === "RETURNED");
  
  const overdueCount = activeRentals.filter(
    (r) => isPast(new Date(r.dueAt)) || r.status === "OVERDUE"
  ).length;

  const handleReturn = (rental: RentalWithItem) => {
    returnMutation.mutate(rental.id);
  };

  return (
    <div className="min-h-screen bg-background">
      <header 
        className="fixed top-0 left-0 right-0 h-14 bg-background/95 backdrop-blur-sm border-b border-border z-50"
        data-testid="header-my-rentals"
      >
        <div className="max-w-md mx-auto h-full flex items-center px-4">
          <h1 className="text-xl font-semibold">My Rentals</h1>
        </div>
      </header>
      
      <main className="pt-14 pb-20 max-w-md mx-auto">
        <OverdueAlert count={overdueCount} />
        
        <div className="p-4">
          <Tabs defaultValue="active" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="active" data-testid="tab-active">
                Active ({activeRentals.length})
              </TabsTrigger>
              <TabsTrigger value="returned" data-testid="tab-returned">
                Returned ({returnedRentals.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="active" className="mt-0">
              {isLoading ? (
                <div className="grid gap-4">
                  {[1, 2].map((i) => (
                    <RentalCardSkeleton key={i} />
                  ))}
                </div>
              ) : activeRentals.length === 0 ? (
                <EmptyState type="no-rentals" />
              ) : (
                <div className="grid gap-4" data-testid="grid-active-rentals">
                  {activeRentals.map((rental) => (
                    <RentalCard
                      key={rental.id}
                      rental={rental}
                      onReturn={handleReturn}
                      isPending={returnMutation.isPending}
                    />
                  ))}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="returned" className="mt-0">
              {isLoading ? (
                <div className="grid gap-4">
                  {[1, 2].map((i) => (
                    <RentalCardSkeleton key={i} />
                  ))}
                </div>
              ) : returnedRentals.length === 0 ? (
                <div 
                  className="text-center py-16 text-muted-foreground"
                  data-testid="empty-returned"
                >
                  No returned items yet
                </div>
              ) : (
                <div className="grid gap-4" data-testid="grid-returned-rentals">
                  {returnedRentals.map((rental) => (
                    <RentalCard
                      key={rental.id}
                      rental={rental}
                      onReturn={handleReturn}
                    />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}
