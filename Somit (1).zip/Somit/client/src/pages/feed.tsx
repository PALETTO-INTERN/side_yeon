import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { SearchHeader } from "@/components/search-header";
import { BottomNav } from "@/components/bottom-nav";
import { ItemCard } from "@/components/item-card";
import { RentalSheet } from "@/components/rental-sheet";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Item } from "@shared/schema";

function ItemCardSkeleton() {
  return (
    <div className="bg-card rounded-lg overflow-hidden border border-card-border">
      <Skeleton className="aspect-square w-full" />
      <div className="p-4 space-y-3">
        <Skeleton className="h-6 w-3/4" />
        <div className="flex gap-2">
          <Skeleton className="h-5 w-20 rounded-full" />
          <Skeleton className="h-5 w-16 rounded-full" />
        </div>
        <Skeleton className="h-9 w-full" />
      </div>
    </div>
  );
}

export default function Feed() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: items = [], isLoading } = useQuery<Item[]>({
    queryKey: ["/api/items"],
  });

  const rentMutation = useMutation({
    mutationFn: async (data: { itemId: string; reason: string; dueAt: string }) => {
      return apiRequest("POST", "/api/rentals", {
        ...data,
        userId: user?.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      setSheetOpen(false);
      setSelectedItem(null);
      toast({
        title: "Success!",
        description: "Item rented successfully. Check My Page for details.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to rent item. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleRentClick = (item: Item) => {
    setSelectedItem(item);
    setSheetOpen(true);
  };

  const handleConfirmRental = (reason: string, dueDate: Date) => {
    if (selectedItem) {
      rentMutation.mutate({
        itemId: selectedItem.id,
        reason,
        dueAt: dueDate.toISOString(),
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SearchHeader 
        searchQuery={searchQuery} 
        onSearchChange={setSearchQuery} 
      />
      
      <main className="pt-14 pb-20 max-w-md mx-auto">
        <div className="p-4">
          <h2 className="text-xl font-semibold mb-4" data-testid="text-feed-title">
            Available Items
          </h2>
          
          {isLoading ? (
            <div className="grid gap-4">
              {[1, 2, 3].map((i) => (
                <ItemCardSkeleton key={i} />
              ))}
            </div>
          ) : filteredItems.length === 0 ? (
            <EmptyState 
              type={searchQuery ? "no-results" : "no-items"} 
              searchQuery={searchQuery}
            />
          ) : (
            <div className="grid gap-4" data-testid="grid-items">
              {filteredItems.map((item) => (
                <ItemCard
                  key={item.id}
                  item={item}
                  onRent={handleRentClick}
                />
              ))}
            </div>
          )}
        </div>
      </main>
      
      <BottomNav />
      
      <RentalSheet
        item={selectedItem}
        open={sheetOpen}
        onClose={() => {
          setSheetOpen(false);
          setSelectedItem(null);
        }}
        onConfirm={handleConfirmRental}
        isPending={rentMutation.isPending}
      />
    </div>
  );
}
